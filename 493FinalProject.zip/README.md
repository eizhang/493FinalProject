Our main project sectio is shown in index.html. Currently we are working on adding more levels and refining the functionality that weaves the sections together. The first four levels contain the animation that will pop up when you loose a level while the other 5 levels do not, the game over screen has still not been created, so currrently you can play the game even when you do no have a life left to play. The maze graphic is also up but the actual maze does not yet work. 

This game is meant to have nonsensical answers, thus we have provided the correct answer to each level such that the instructors can play the whole game with minor frustration:

Question 1: the Blue
Question 2: Click the question mark "?" in the question
Question 3: Michigan (obviously)
Question 4: Spam the "study" button until bar fills
Question 5: H
Question 6: Berry->Apple->Nectarine->Apple->Nectarine->Apple
Question 7: Click on Kuzco (the llama)
Question 8: top left most button (after the flash)
Question 9: Behind you
Question 10: Can you not
Question 11: Click the squirrel
Question 12: red-orange-white-purple-orange-red-teal
Question 13: click on baby corgi, follow path with mouse cursor, click momma corgi
Question 14: Window
Question 15: Pause and don't click anything for 7 seconds 
Question 16: LEGEND

Game over!! 

